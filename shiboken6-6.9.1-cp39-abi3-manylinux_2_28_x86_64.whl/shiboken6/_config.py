shiboken_library_soversion = "6.9"

version = "6.9.1"
version_info = (6, 9, 1, "", "")

__build_date__ = '2025-05-31T17:31:12+00:00'




__setup_py_package_version__ = '6.9.1'

